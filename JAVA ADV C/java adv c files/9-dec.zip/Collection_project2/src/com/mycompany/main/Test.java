/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import com.mycompany.sort.SortByName;
import com.mycompany.sort.SortByRollNo;
import com.mycompany.student.Student;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/**
 *
 * @author ankit
 */
public class Test {
    public static void main(String[] args) {
        Student s1=new Student();    
    Student s2=new Student();
    Student s3=new Student();
     
    s1.setRoll(102);
    s1.setName("Shamlal");
    s1.setPer(15.5f);
    
    s2.setRoll(101);
    s2.setName("Ramlal");
    s2.setPer(12.3f);
    
    s3.setRoll(103);
    s3.setName("Babulal");
    s3.setPer(23.5f);
    
        ArrayList<Student> al=new ArrayList<>();
        
        al.add(s1);
        al.add(s2);
        al.add(s3);
    
        //System.out.println(al);
        
        
        Iterator itr=al.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
     
        
        Collections.sort(al, new SortByRollNo());
        
        System.out.println("After sorting Roll No-");
        
        Iterator itr2=al.iterator();
        while(itr2.hasNext())
        {
            System.out.println(itr2.next());
        }
        
        Collections.sort(al, new SortByName());
        System.out.println("After Sorting by Name-");
    
     Iterator itr3=al.iterator();
        while(itr3.hasNext())
        {
            System.out.println(itr3.next());
        }
    
    }
 
}
