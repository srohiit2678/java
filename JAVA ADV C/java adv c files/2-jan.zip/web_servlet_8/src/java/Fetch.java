

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Fetch extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
    
        try
    {
        
       
        //load the driver class
     Class.forName("com.mysql.cj.jdbc.Driver");
   //make connection object
     Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/school","root","root");
   //make the statement object
     Statement smt=cn.createStatement();
     
     //execute query
     ResultSet rs=smt.executeQuery("select * from student");
    out.println("<h2>Student List</h2>");
    out.println("<table border='2'>");
    out.println("<tr><th>Roll No</th><th>Name</th><th>Percentage</th><th>Edit</th><th>Delete</th></tr>");
     while(rs.next())
     {
        int roll=rs.getInt("rollno");
        String name=rs.getString("name");
        float per=rs.getFloat("percentage");
     out.println("<tr><td>"+roll+"</td><td>"+name+"</td><td>"+per+"</td><td><a href='Edit'><center><img src='images/edit.png'width='10%' height='10%'></center></a></td><td><a href='Delete'>Delete</a></td></tr>");
     }
     out.println("</table>");
     
    cn.close();
    }
    catch(Exception e)
    {
        System.out.println(e.getMessage());   
    }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
