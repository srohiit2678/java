
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Serv extends HttpServlet
{
  public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException
  {
      res.setContentType("text/html");
     PrintWriter pw=res.getWriter();
    pw.println("Hello<br>"); 
    pw.println("<h1>Welcome</h1>");  
  }
}