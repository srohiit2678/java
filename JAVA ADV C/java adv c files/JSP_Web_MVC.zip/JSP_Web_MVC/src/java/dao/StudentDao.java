/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Student;

/**
 *
 * @author ankit
 */
public interface StudentDao {
   
    public int insert(Student s);
    //public int update(Student s);
    //public void delete(Student s);
    
}
