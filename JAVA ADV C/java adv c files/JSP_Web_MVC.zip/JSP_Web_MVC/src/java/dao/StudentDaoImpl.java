
package dao;

import entity.Student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author ankit
 */
public class StudentDaoImpl implements StudentDao
{

    @Override
    public int insert(Student s) {
        
    
     try
     {
       //Load the driver class
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//create the connection
		
		Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/CLG","root","root");
		
		//Make the statement object
		
	Statement smt=cn.createStatement();
		
		//execute query
	int i=smt.executeUpdate("insert into student values("+s.getRollNo()+",'"+s.getName()+"',"+s.getPercentage()+")");
		
		if(i>0)
                {
                    return 1;
                }
        
        cn.close();
    }
     catch(Exception e)
     {
         System.out.println("valueeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee===="+e.getMessage());
     }
     return 0; 
    }    
    
    }  
  
    
    

