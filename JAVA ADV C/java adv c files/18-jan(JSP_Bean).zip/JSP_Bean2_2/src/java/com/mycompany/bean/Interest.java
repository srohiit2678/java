/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bean;

/**
 *
 * @author ankit
 */
public class Interest {

public float simpleInterest(float p,float r,float t)
    {
     float si=p*r*t/100;
     return si;
    }
    

    
}
