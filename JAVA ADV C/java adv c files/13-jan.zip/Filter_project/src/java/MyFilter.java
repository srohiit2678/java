
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyFilter implements Filter
{

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        
        PrintWriter pw=response.getWriter();
    String name=request.getParameter("n");
    String age=request.getParameter("age");
    String mobile=request.getParameter("mob");
    
    if(name.equals(""))
    {
     pw.println("Name is required");
    }
    else if(age.equals(""))
    {
        pw.println("Age is required");
    }
    else if(mobile.equals(""))
    {
     pw.println("Mobile is required");
    }
    else
    {
        pw.println("<body bgcolor='orange'>");
        pw.println("<pre>");
        chain.doFilter(request, response);
    pw.println("</pre>");
     pw.println("</body>");
    }
    }

    
    
}