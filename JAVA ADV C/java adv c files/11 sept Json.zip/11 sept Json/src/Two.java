//Creating JSON From Map
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ankit
 */
public class Two {
    
    public static void main(String[] args) {
        Map<String, String> map = new HashMap<>();
map.put("name", "jon doe");
map.put("age", "22");
map.put("city", "chicago");
JSONObject jo = new JSONObject(map);

        System.out.println(jo);
    }
    
    
}
