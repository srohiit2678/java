//Creating JSONArray
import org.json.JSONArray;
import org.json.JSONObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ankit
 */
public class Five {
    public static void main(String[] args) {
     
      JSONArray ja = new JSONArray();
ja.put(Boolean.TRUE);
ja.put("Shamlal");

JSONObject jo = new JSONObject();
jo.put("name", "Ramlal");
jo.put("age", "22");
jo.put("city", "chicago");

ja.put(jo); 

        System.out.println(ja);
        
    }
    
}
