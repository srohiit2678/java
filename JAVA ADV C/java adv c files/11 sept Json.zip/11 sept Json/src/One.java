//Creating JSON Directly From JSONObject
import org.json.JSONObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ankit
 */
public class One {
    public static void main(String[] args) {
        
        JSONObject jo = new JSONObject();
jo.put("name", "Ramlal");
jo.put("age", "22");
jo.put("city", "Indore");


System.out.println(jo);
    }
    
}
