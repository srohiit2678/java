
import org.json.JSONArray;

//Creating JSONArray Directly From JSON String

public class Six {

    public static void main(String[] args) {
        String s="[true, \"sundar\", 215]";
JSONArray ja = new JSONArray(s);
        System.out.println(ja);   
    }

}
