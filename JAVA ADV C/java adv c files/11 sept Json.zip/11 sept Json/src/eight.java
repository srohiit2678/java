
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONTokener;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ankit
 */
//Producing JSONArray Directly From Comma Delimited Text
public class eight {
    public static void main(String[] args) {
        JSONArray ja = CDL.rowToJSONArray(new JSONTokener("England, USA, Canada"));
        System.out.println(ja);
    }
}
