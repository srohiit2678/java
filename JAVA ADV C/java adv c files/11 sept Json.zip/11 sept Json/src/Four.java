//Serialize Java Object to JSON
import org.json.JSONObject;


public class Four {
    public static void main(String[] args) {
        
        DemoBean demo = new DemoBean();
demo.setId(1);
demo.setName("Shamlal");
demo.setActive(true);

JSONObject jo = new JSONObject(demo);
        System.out.println(jo);
    }
  
}
