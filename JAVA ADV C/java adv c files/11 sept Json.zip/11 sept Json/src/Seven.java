//Creating JSONArray Directly From a Collection or an Array
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ankit
 */
public class Seven {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
list.add("California");
list.add("Texas");
list.add("Hawaii");
list.add("Alaska");

JSONArray ja = new JSONArray(list);
        System.out.println(ja);
    }
}
