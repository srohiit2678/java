//Creating JSONObject From JSON String
import org.json.JSONObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ankit
 */
public class Three {
   
    public static void main(String[] args) {
        JSONObject jo = new JSONObject(
  "{\"city\":\"chicago\",\"name\":\"Ramlal\",\"age\":\"22\"}"
);
        
        System.out.println("value="+jo);
    }
    
    
    
}
