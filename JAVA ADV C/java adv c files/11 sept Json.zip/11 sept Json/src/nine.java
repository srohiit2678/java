
import org.json.CDL;
import org.json.JSONArray;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ankit
 */
//Producing Comma Delimited Text From JSONArray
public class nine {
    
    public static void main(String[] args) {
        JSONArray ja = new JSONArray("[\"England\",\"USA\",\"Canada\"]");
String cdt = CDL.rowToString(ja);
        System.out.println(cdt);
    }
    
    
    
}
