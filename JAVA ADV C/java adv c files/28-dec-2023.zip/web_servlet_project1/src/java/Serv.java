
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Serv implements Servlet
{

    public Serv()
    {
        System.out.println("Constructorrrrrrrrrr");
    }
    
    
    @Override
    public void init(ServletConfig config) throws ServletException {
        System.out.println("Inittttttttttt"); 
    }

    @Override
    public ServletConfig getServletConfig() {
    return null;    
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
    
        PrintWriter pw=res.getWriter();
        pw.println("Hello");
        pw.print("Welcome");
        System.out.println("Serviceeeeeeeeeeeeeeeeee");
    
    }

    @Override
    public String getServletInfo() {
    return null;    
    }

    @Override
    public void destroy() {
        System.out.println("Destroyyyyyyyy");    
    }
   
    
    
}
        