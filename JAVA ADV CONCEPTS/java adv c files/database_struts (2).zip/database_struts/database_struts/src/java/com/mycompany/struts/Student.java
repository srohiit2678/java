/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.struts;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author ankit
 */
public class Student extends ActionSupport {
    int roll;
    String name;
    float percentage;

    public int getRoll() {
        return roll;
    }

    public void setRoll(int roll) {
        this.roll = roll;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

    
    
    
    @Override
    public String execute() throws Exception {
    try
    {
     Class.forName("com.mysql.cj.jdbc.Driver");
		
		//create the connection
		
	 Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/struts","root","");
       Statement smt=cn.createStatement();
		
		//execute query
	int i=smt.executeUpdate("insert into student values("+roll+",'"+name+"',"+percentage+")");
		
		if(i>0)
                {
                    return "success";
                }   
    }
        catch(Exception e)
        {
            System.out.println("value="+e.getMessage());
        }
    return "error";    
    }
    
}
