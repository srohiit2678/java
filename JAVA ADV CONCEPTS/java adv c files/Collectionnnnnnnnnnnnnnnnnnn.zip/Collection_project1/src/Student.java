
public class Student implements Comparable<Student>
{

int roll;
String name;
float per;

    public Student(int roll, String name, float per) {
        this.roll = roll;
        this.name = name;
        this.per = per;
    }

    @Override
    public String toString() {
        return roll + ":" + name + ":" + per;
    }

    @Override
    public int compareTo(Student s) {
        
    if(this.roll>s.roll)
    {
        return 1;
    }
    else if(this.roll<s.roll)
    {
        return -1;
    }
    else
    {
        return 0;
    }
    }

    


    
}
