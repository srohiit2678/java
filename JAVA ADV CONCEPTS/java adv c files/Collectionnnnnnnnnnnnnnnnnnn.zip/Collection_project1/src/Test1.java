
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class Test1 {

    public static void main(String[] args) {
        
    Student s1=new Student(102,"Shamlal",12.3f);    
    Student s2=new Student(103,"Babulal",15.5f);
    Student s3=new Student(101,"Ramlal",23.45f);
     
        ArrayList<Student> al=new ArrayList<>();
        
        al.add(s1);
        al.add(s2);
        al.add(s3);
    
        //System.out.println(al);
        
        
        Iterator itr=al.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
        
        
        System.out.println("After sorting Roll no-");
        
        
        Collections.sort(al);
        
         Iterator itr2=al.iterator();
        while(itr2.hasNext())
        {
            System.out.println(itr2.next());
        }
        
        
    }

    
}
