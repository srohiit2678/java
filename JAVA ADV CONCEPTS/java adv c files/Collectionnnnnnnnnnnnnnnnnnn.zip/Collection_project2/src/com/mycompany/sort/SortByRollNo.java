/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sort;

import com.mycompany.student.Student;
import java.util.Comparator;

/**
 *
 * @author ankit
 */
public class SortByRollNo implements Comparator
{

    @Override
    public int compare(Object o1, Object o2) {
    Student s1=(Student)o1;    
    Student s2=(Student)o2;
    
    
    if(s1.roll>s2.roll)
    {
        return 1;
    }
    else if(s1.roll<s2.roll)
    {
        return -1;
    }
    else
    {
        return 0;
    }
    }
   
    
    
    
    
}
