/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sort;

import com.mycompany.student.Student;
import java.util.Comparator;

/**
 *
 * @author ankit
 */
public class SortByName implements Comparator<Student>
{

    @Override
    public int compare(Student s1, Student s2) {
     
      return s1.name.compareTo(s2.name);
    
    }
    
}
