/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.student;

/**
 *
 * @author ankit
 */
public class Student {
   
    
    
    public int roll;
public String name;
public float per;

    public Student(int roll, String name, float per) {
        this.roll = roll;
        this.name = name;
        this.per = per;
    }

    @Override
    public String toString() {
        return roll + ":" + name + ":" + per;
    }

}
